﻿Public Class Form1

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        If txtUsername.Text = "Gerold" And txtPassword.Text = "12345" Then
            MsgBox("You login successfully")
            Form2.Show()

        Else
            MsgBox("Wrong Username or Password")
        End If

        txtUsername.Clear()
        txtPassword.Clear()



    End Sub



End Class
